﻿using HevoDrawing;
using HevoDrawing.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace HevoInsider.Charts
{
    public class Invest : RectDrawingCanvasContainer
    {
        ChartVisual chart = new ChartVisual();
        DiscreteAxis axisX = new CategoryAxis(AxisPosition.Buttom) { Name = "涨跌幅", ValueFormat = "t", SplitValueFormat = "t", IsInterregional = true, ShowGridLine = false, IsGridLineClose = true };

        BarSeriesVisual barSeries = new BarSeriesVisual() { Pen = null };

        ContinuousAxis axisY = new ContinuousAxis(AxisPosition.Left) { ShowGridLine = true, AxisPen = new Pen(Brushes.Green, 1) };

        RectDrawingCanvas rectDrawingCanvas = new RectDrawingCanvas();
        public override RectDrawingCanvas Canvas => rectDrawingCanvas;

        public Invest()
        {
            BorderThickness = new Thickness(1);
            BorderBrush = Brushes.Black;

            chart.IntersectChanged += Chart_IntersectChanged;

            chart.Offsets = new PaddingOffset(20);

            axisX.IsInterregional = true;

            chart.AddAsixY(axisY);
            chart.AddAsixX(axisX);

            chart.AddSeries(barSeries);
            barSeries.Fill = (data) =>
            {
                var str = ((Value<string>)data).Data;
                switch (str)
                {
                    case "≤-7":
                    case "-7~-5":
                    case "-5~-3":
                    case "-3~0":
                        return Brushes.Green;
                    case "0":
                        return Brushes.Yellow;
                    case "0~3":
                    case "3~5":
                    case "5~7":
                    case "≥7":
                        return Brushes.Red;
                }
                return Brushes.Black;
            };


            rectDrawingCanvas.AddChild(chart);
            Canvas.DataSource = chart.DataSource;
            IsVisibleChanged += ChartItem_IsVisibleChanged;

            DockPanel dock = new DockPanel();
            DockPanel title = new DockPanel();
            title.VerticalAlignment = VerticalAlignment.Center;
            title.AddChild(new TextBlock() { Text = "涨跌统计" }, Dock.Left);
            dock.AddChild(title, Dock.Top);
            dock.AddChild(rectDrawingCanvas, Dock.Top);
            Content = dock;
        }

        private void Chart_IntersectChanged(Dictionary<string, SeriesData> data)
        {
        }

        private void ChartItem_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                StartDataFeed();
            }
        }

        private void StartDataFeed()
        {
            Dictionary<string, double> dic = new Dictionary<string, double>()
            {
                { "≤-7",9},
                { "-7~-5",18},
                { "-5~-3",52},
                { "-3~0",449},
                { "0",62},
                { "0~3",2444},
                { "3~5",405},
                { "5~7",165},
                { "≥7",173 }
            };
            barSeries.VisualData = dic.ToVisualData();
            barSeries.BarWidth = new GridLength(0.5, GridUnitType.Star);
            rectDrawingCanvas.Replot();
        }
    }
}
